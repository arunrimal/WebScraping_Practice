from setuptools import setup
setup(name="pyazure",
    version="0.1",
    description="this is for web scraping",
    long_description="especially for Greenhouse web scraping and many more",
    author="arun",
    packages=['pyazure']
)
  